<?php
error_reporting(-1);
session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/funcs.php';
$products5 = get_products5();
$products6 = get_products6();
?>
<!doctype html>
<html>
<head>
    <title>User Profile Widget</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" type="text/css" href="..\css\index.css">
    <link rel="stylesheet" href="https://bootstraptema.ru/plugins/2015/bootstrap3/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<header class="header">
<div class="otstup">
  <div class="logo-headar">
    <img href="indexxx.php" src="logo.svg"   id="logo-headar" >
  </div>
  <div class="menu">
	   <a href="indexxx.php" class="underline-one weg">Домой</a>
  </div>
<div class="menu">
      <a href="..\zdor\pages\histor.html" class="underline-one weg">История</a>
  </div>
<div class="menu">
<p> <a href="register.php?logout='1'" class="underline-one weg" style="color: black;">Зарегистрироваться</a> </p>
</div>
<div class="menu">
<p> <a href="login.php?logout='1'" class="underline-one weg" style="color: black; ">Войти</a> </p>
</div>
<div class="menu">
<p> <a href="login.php?logout='1'"  class="underline-one weg" style="color: red;">Выйти</a> </p>
</div>
<div class="menu">
<p> <a href="users.php"  class="underline-one weg" style="color: red;">Профиль</a> </p>
</div>   

<div class="menu">


</div>

</div>

</header>


<br><br><br><br><br><br><br><br><br><br>
<div class="container">
<div id="main">


 <div class="row" id="real-estates-detail">
 <div class="col-lg-4 col-md-4 col-xs-12">
 <div class="panel panel-default">
 <div class="panel-heading">
 <header class="panel-title">
 <div class="text-center">
 <strong>Пользователь сайта</strong>
 </div>
 </header>
 </div>
 <div class="panel-body">
 <div class="text-center" id="author">
 <?php if (!empty($products6)): ?>
                    <?php foreach ($products6 as $product): ?>
<a href="#"><img src="img/<?= $product['img'] ?>"></a>
 <?php endforeach; ?>
                <?php endif; ?>
 <h3>Евгений Лизогубинко</h3>
 <small class="label label-warning">Российская Федерация</small>
 <p>Я простой Русский любитель школьниц</p>
 <p class="sosmed-author">
 <a href="#"><i class="fa fa-facebook" title="Facebook"></i></a>
 <a href="#"><i class="fa fa-twitter" title="Twitter"></i></a>
 <a href="#"><i class="fa fa-google-plus" title="Google Plus"></i></a>
 <a href="#"><i class="fa fa-linkedin" title="Linkedin"></i></a>
 </p>
 </div>
 </div>
 </div>
 </div>
 <div class="col-lg-8 col-md-8 col-xs-12">
 <div class="panel">
 <div class="panel-body">
 <ul id="myTab" class="nav nav-pills">
 <li class="active"><a href="#detail" data-toggle="tab">О пользователе</a></li>
 <li class=""><a href="#contact" data-toggle="tab">Отправить сообщение</a></li>
 </ul>
 <div id="myTabContent" class="tab-content">
<hr>

 <h4>История профиля</h4>
 <table class="table table-th-block">
 <tbody>
 <tr><td class="active">Зарегистрирован:</td><td>05-05-2023</td></tr>
 <tr><td class="active">Страна:</td><td>Россия</td></tr>
 <tr><td class="active">Город:</td><td>Челябинск</td></tr>
 <tr><td class="active">Пол:</td><td>Мужской</td></tr>
 <tr><td class="active">Полных лет:</td><td>32</td></tr>
 <tr><td class="active">Семейное положение:</td><td>Женат</td></tr>
 <tr><td class="active">Покупок сделано:</td><td>39</td></tr>
 <?php if (!empty($products5)): ?>
                    <?php foreach ($products5 as $product): ?>
 <tr><td class="active">Статус:</td><td><?= $product['username'] ?></td></tr>
 <?php endforeach; ?>
                <?php endif; ?>
 <tr><td class="active">Рейтинг пользователя:</td><td><i class="fa fa-star" style="color:red"></i> <i class="fa fa-star" style="color:red"></i> <i class="fa fa-star" style="color:red"></i> <i class="fa fa-star" style="color:red"></i> 4/5</td></tr>
</tbody>
 </table>
 </div>
 <div class="tab-pane fade" id="contact">
 <p></p>
 <form role="form">
 <div class="form-group">
 <label>Ваше имя</label>
 <input type="text" class="form-control rounded" placeholder="Укажите Ваше Имя">
 </div>
 <div class="form-group">
 <label>Ваш телефон</label>
 <input type="text" class="form-control rounded" placeholder="(+7)(095)123456">
 </div>
 <div class="form-group">
 <label>E-mail адрес</label>
 <input type="email" class="form-control rounded" placeholder="Ваш Е-майл">
 </div>
 <div class="form-group">
 <div class="checkbox">
 <label>
 <input type="checkbox"> Согласен с условиями
 </label>
 </div>
 </div>
 <div class="form-group">
 <label>Текст Вашего сообщения</label>
 <textarea class="form-control rounded" style="height: 100px;"></textarea>
 <p class="help-block">Текст сообщения будет отправлен пользователю</p>
 </div>
 <div class="form-group">
 <button type="submit" class="btn btn-success" data-original-title="" title="">Отправить</button>
 </div>
 </form>
 </div>
 </div>
 </div>
 </div>
 </div>
 </div>
</div>

</div><!-- /.main -->
</div><!-- /.container -->
    </div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer class="footer">
    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave4"></div>
    </div>
    <ul class="social-icon">
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-facebook"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-twitter"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-linkedin"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-instagram"></ion-icon>
        </a></li>
    </ul>
    <ul class="menu">
    <li class="menu__item"><a class="menu__link" href="#">Главная</a></li>
      <li class="menu__item"><a class="menu__link" href="#">О нас</a></li>
      <li class="menu__item"><a class="menu__link" href="#">История</a></li>
      <li class="menu__item"><a class="menu__link" href="#">Контакты</a></li>
      <li class="menu__item"><a class="menu__link" href="#">Наши мастера</a></li>

    </ul>
    <p>&copy;2023 Milana Shop | All Rights Reserved</p>
  </footer>
</body>

<script src="https://bootstraptema.ru/plugins/jquery/jquery-1.11.3.min.js"></script>
<script src="https://bootstraptema.ru/plugins/2015/b-v3-3-6/bootstrap.min.js"></script>
</html>