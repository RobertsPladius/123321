<header>
<?php include ('header.php');?>
</header>

<link rel="stylesheet" type="text/css" href="..\css\index.css">
   <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">
  <link rel="shortcut icon" href="logo.svg" type="image/x-icon">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
      <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php

if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['message'])) {

    $conn = new mysqli('localhost', 'root', '', 'magaz1');

    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $message = $conn->real_escape_string($_POST['message']);

    $sql = "INSERT INTO reviews (name, email, message) VALUES ('$name', '$email', '$message')";

    if($conn->query($sql)) {
        echo "Ваш отзыв отправлен!";
    } else {
        echo "Ошибка: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<?php

$conn = new mysqli('localhost', 'root', '', 'magaz1');

$sql = "SELECT * FROM reviews ORDER BY date DESC";

$result = $conn->query($sql);
if($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
        echo '<p><strong>' . $row['name'] . '</strong> ' . $row['date'] . '<br>' . $row['message'] . '</p>';
    }
} else {
    echo "Отзывов пока нет.";
}

$conn->close();
?>

<?php include('footer.php');?>