<?php

function debug(array $data): void
{
    echo '<pre>' . print_r($data, 1) . '</pre>';
}

function get_products(): array
{
    global $pdo;
    $res = $pdo->query("SELECT * FROM products where slug = 1");
    return $res->fetchAll();
}
function get_products1(): array
{
    global $pdo;
    $res = $pdo->query("SELECT * FROM products where slug = 2");
    return $res->fetchAll();
}
function get_products2(): array
{
    global $pdo;
    $res = $pdo->query("SELECT * FROM products where slug = 3");
    return $res->fetchAll();
}
function get_products3(): array
{
    global $pdo;
    $res = $pdo->query("SELECT * FROM products where slug = 4");
    return $res->fetchAll();
}
function get_products5(): array
{
    global $pdo;
    $res = $pdo->query("SELECT * FROM users where id = 1");
    return $res->fetchAll();
}
function get_products6(): array
{
    global $pdo;
    $res = $pdo->query("SELECT * FROM imgprof where id = 1");
    return $res->fetchAll();
}


function get_product(int $id): array
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}
function add_to_cart($product): void{
    if (isset($_SESSION['cart'][$product['id']])){
        $_SESSION['cart'][$product['id']]['qty'] += 1;
    } else{
        $_SESSION['cart'][$product['id']] = [
            'title'=> $product['title'],
            'slug'=> $product['slug'],
            'price'=> $product['price'],
            'qty'=> 1,
            'img'=> $product['img']
        ];
    }
    $_SESSION['cart.qty'] = !empty($_SESSION['cart.qty']) ? ++$_SESSION['cart.qty']:1;
    $_SESSION['cart.sum'] = !empty($_SESSION['cart.sum']) ? $_SESSION['cart.sum'] + $product['price']: $product['price'];
}




