<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="..\css\index.css">
  <link rel="stylesheet" href="../css/style.css">

</head>


<body>
<header class="header">
<div class="otstup">
  <div class="logo-headar">
    <img href="indexxx.php" src="logo.svg"   id="logo-headar" >
  </div>
<div class="menu">
<p> <a href="register.php?logout='1'" class="underline-one weg" style="color: black;">Зарегистрироваться</a> </p>
</div>
<div class="menu">
<p> <a href="login.php?logout='1'" class="underline-one weg" style="color: black; ">Войти</a> </p>
</div>



<div class="menu">


</div>

</div>

</header>
<br><br><br><br><br><br><br><br><br><br>
<div class="padding" >

<div class="container">
	<section id="content">
  <form method="post" action="login.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Логин</label>
  		<input class="text-field__input" placeholder="Ваш Логин" id="username" type="text" name="username" >
  	</div>
  	<div class="input-group">
  		<label>Пароль</label>
  		<input class="text-field__input" id="password" placeholder="Пароль" type="password" name="password">
  	</div>
  	<div class="input-group">
    <input type="submit" class="btn" name="login_user" value="Log in" />
  	</div>
  	<p>
  		Нет аккаунта? <a href="register.php">Регистрация</a>
  	</p>
		</form><!-- form -->
		
	</section><!-- content -->
</div><!-- container -->
  
  </form>
  </div>
  </div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer class="footer">
    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave4"></div>
    </div>
    <ul class="social-icon">
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-facebook"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-twitter"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-linkedin"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-instagram"></ion-icon>
        </a></li>
    </ul>
    <ul class="menu">
    <li class="menu__item"><a class="menu__link" href="#">Главная</a></li>
      <li class="menu__item"><a class="menu__link" href="#">О нас</a></li>
      <li class="menu__item"><a class="menu__link" href="#">История</a></li>
      <li class="menu__item"><a class="menu__link" href="#">Контакты</a></li>
      <li class="menu__item"><a class="menu__link" href="#">Наши мастера</a></li>

    </ul>
    <p>&copy;2023 Milana Shop | All Rights Reserved</p>
  </footer>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</html>