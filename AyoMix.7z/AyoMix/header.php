<header class="header">
<div class="otstup">
  <div class="logo-headar">
    <img href="indexxx.php" src="logo.svg"   id="logo-headar" >
  </div>
  <div class="menu">
	   <a href="indexxx.php" class="underline-one weg">Домой</a>
  </div>
<div class="menu">
      <a href="topik.php" class="underline-one weg">Товары</a>
  </div>
<div class="menu">
  
<p> <a href="users.php"  class="underline-one weg" style="color: black;">Профиль</a> </p>
</div>
<div class="menu">
<p> <a href="login.php?logout='1'" class="underline-one weg" style="color: black; ">Войти</a> </p>
</div>
<div class="menu">
<p> <a href="login.php?logout='1'"  class="underline-one weg" style="color: black;">Выйти</a> </p>
</div>
