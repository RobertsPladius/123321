<!DOCTYPE html>
<html>
<head>
	 <title>MILANA</title>
	 <meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" type="text/css" href="..\css\index.css">
   <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">
  <link rel="shortcut icon" href="logo.svg" type="image/x-icon">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
</head>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<body>

<div class="menutelefona">
    <input type="checkbox" id="hmt" class="hidden-menu-ticker">
<label class="btn-menu" for="hmt">
    <span class="first"></span>
    <span class="second"></span>
    <span class="third"></span>
</label>
  <ul class="hidden-menu">
    <li><a class="dek" href="#">Домой</a></li>  
    <li><a class="dek" href="..\zdor\pages\histor.html">История</a></li>
    <li><a class="dek" href="..\zdor\pages\katalog.html">Каталог</a></li>  
    <li><a class="dek" href="..\zdor\pages\kontakt.html">Контакты</a></li>  
    <li><a class="dek" href="..\zdor\pages\nas.html">О нас</a></li> 
    
  </ul>
</div>

<?php include ('header.php');?>






</header>
<br>
<br>
<br>
<br>
<div class="slideshow-container">

<div class="swiper mySwiper">
    <div class="swiper-wrapper">
      <div class="swiper-slide"><img style="height:600px;" src="https://hoff.ru/upload/hoff_resize/upload/iblock/074/rhy5fxgwyqyjso5neslc2l7jspbse1jb.jpg/2000x676_75.webp" alt="" srcset=""></div>
      <div class="swiper-slide"><img style="height:600px;" src="https://hoff.ru/upload/hoff_resize/upload/iblock/565/9t6jo1xoidrixtrmey6p1zknlgwn748l.jpg/2000x676_75.webp" alt="" srcset=""></div>
      <div class="swiper-slide"><img style="height:600px;" src="https://hoff.ru/upload/hoff_resize/upload/iblock/8a6/v2szs12xagcngao9t9u83vt70pwvn3l9.jpg/2000x676_75.webp" alt="" srcset=""></div>
      <div class="swiper-slide"><img style="height:600px;" src="https://hoff.ru/upload/hoff_resize/upload/iblock/57e/tn2x982gf23za1nseu2m4wxoe66o4d5b.jpg/2000x676_75.webp" alt="" srcset=""></div>
    </div>
    <div class="swiper-pagination"></div>
    <div class="autoplay-progress">
      <svg viewBox="0 0 48 48">
        <circle cx="24" cy="24" r="20"></circle>
      </svg>
      <span></span>
    </div>
  </div>
</div>

<div class="portfolio-wrap">
<div class="portfolio-item">
<div class="portfolio-item-wrap">
<a href="#">
<img src="https://cdn.1hmm.ru/upload/iblock/7a6/367_hmm_400_400_100.webp" height="100%">
<div class="portfolio-item-inner">
<div class="portfolio-heading">
<h3>Гостинная</h3>
</div>
<ul>
</ul>
</div>
</a>
</div>
</div>

<div class="portfolio-item">
<div class="portfolio-item-wrap">
<a href="topik.php">
<img src="https://cdn.1hmm.ru/upload/iblock/c5e/370_hmm_400_400_100.webp" height="100%">
<div class="portfolio-item-inner">
<div class="portfolio-heading">
<h3>Спальня</h3>
</div>
</div>
</a>
</div>
</div>

<div class="portfolio-item">
<div class="portfolio-item-wrap">
<a href="#">
<img src="https://cdn.1hmm.ru/upload/iblock/199/371_hmm_400_400_100.webp" height="100%">
<div class="portfolio-item-inner">
<div class="portfolio-heading">
<h3>Шкафы</h3>
</div>
</div>
</a>
</div>
</div>

<div class="portfolio-item">
<div class="portfolio-item-wrap">
<a href="#">
<img src="https://cdn.1hmm.ru/upload/iblock/ec9/Hallway_hmm_400_400_100.webp" height="100%">
<div class="portfolio-item-inner">
<div class="portfolio-heading">
<h3>Прихожая</h3>
</div>
</div>
</a>
</div>
</div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
</div>
<?php include('footer.php');?>

</body>
<script>
  //Карусель
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}  // управление смены картинок при помощии кружков снизу карусели  
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 3500); // скорость смены изображения сейчас оно равно=3.5сек
}
</script>
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>

  <!-- Initialize Swiper -->
  <script>
    const progressCircle = document.querySelector(".autoplay-progress svg");
    const progressContent = document.querySelector(".autoplay-progress span");
    var swiper = new Swiper(".mySwiper", {
      spaceBetween: 30,
      centeredSlides: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev"
      },
      on: {
        autoplayTimeLeft(s, time, progress) {
          progressCircle.style.setProperty("--progress", 1 - progress);
          progressContent.textContent = `${Math.ceil(time / 1000)}s`;
        }
      }
    });
  </script>
<script>
$(document).ready(function(){
	load_data();
	function load_data(query)
	{
		$.ajax({
			url:"fetch.php",
			method:"post",
			data:{query:query},
			success:function(data)
			{
				$('#result').html(data);
			}
		});
	}
	
	$('#search_text').keyup(function(){
		var search = $(this).val();
		if(search != '')
		{
			load_data(search);
		}
		else
		{
			load_data();			
		}
	});
});
</script>
<script src="..\js\app.js"></script>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</main>