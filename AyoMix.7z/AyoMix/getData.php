<?php

require_once 'config.php';
if (isset($_POST['query_find'])) {
    $query_find = mysqli_real_escape_string($conn, $_POST['query_find']);
    $query = mysqli_query($conn, "SELECT * FROM products where title like '%$query_find%' or price like '%$query_find%' or slug like '%$query_find%' order by img limit 20");
    $output = '';
    if ($query->num_rows > 0) {
        while ($row = mysqli_fetch_array($query)) {
            $output .= '<tr>
    <td>' . $row['title'] . '</td>
    <td>' . $row['price'] . '</td>
    <td>' . $row['slug'] . '</td>
    <td>' . $row['id'] . '</td>
  </tr>';
        }
    } else {
        $output = '
  <tr>
    <td colspan="4"> No result found. </td>   
  </tr>';
    }
    echo $output;
}
?>
