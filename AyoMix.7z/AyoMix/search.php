
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Поиск</title>
        
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">      
        <meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" type="text/css" href="..\css\index.css">
   <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">
  <link rel="shortcut icon" href="logo.svg" type="image/x-icon">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    </head>
    <body>
    <?php include ('header.php');?>




</header>
<br><br><br><br><br>
        <div class="container" style="max-width:800px;margin:0 auto;margin-top:50px;">  
            <div>
                <h2 style="margin-bottom:50px;">Поиск</h2>
                <div>
                    <div style="margin-bottom:30px;"><input type="text" class="form-control" id="query_find" placeholder="Search"/></div>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Название</th>
                                <th>Цена</th>
                                <th>Категория</th>
                                <th>Id товара</th>
                            </tr>
                        </thead>
                        <tbody id="tbl_body">
                            <?php
                            
                            
                                ?>
                                <tr>
                                    <td><?php echo $row['title']; ?></td>
                                    <td><?php echo $row['price']; ?></td>
                                    <td><?php echo $row['slug']; ?></td>
                                    <td><?php echo $row['img']; ?></td>
                                    <td><?php echo $row['id']; ?></td>
                                </tr>
                            <?php  ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <footer class="footer">
    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave4"></div>
    </div>
    <ul class="social-icon">
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-facebook"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-twitter"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-linkedin"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-instagram"></ion-icon>
        </a></li>
    </ul>
    <ul class="menu">
      <li class="menu__item"><a class="menu__link" href="#">Главная</a></li>
      <li class="menu__item"><a class="menu__link" href="#">О нас</a></li>
      <li class="menu__item"><a class="menu__link" href="#">История</a></li>
      <li class="menu__item"><a class="menu__link" href="#">Контакты</a></li>
      <li class="menu__item"><a class="menu__link" href="#">Наши мастера</a></li>

    </ul>
    <p>&copy;2023 Milana Shop | All Rights Reserved</p>
  </footer>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script>
            $(document).on("keyup", "#query_find", function () {
                var query_find = $("#query_find").val();
                $.ajax({
                    url: 'getData.php',
                    type: 'POST',
                    data: {query_find: query_find},
                    success: function (data) {
                        $("#tbl_body").html(data);
                    }
                });
            });
        </script>      
    </body>
</html>