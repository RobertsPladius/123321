<?php
error_reporting(-1);
session_start();
require_once __DIR__ . '/inc/db.php';
require_once __DIR__ . '/inc/funcs.php';
$products1 = get_products1();

?>
<!DOCTYPE html>
<html>
<head>
	 <title></title>
	 <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" type="text/css" href="..\css\index.css">
   <link rel="stylesheet" type="text/css" href="..\css\ubka.css">
   <link rel="stylesheet" type="text/css" href="..\css\main.css">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
   <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">
  <link rel="shortcut icon" href="logo.svg" type="image/x-icon">
</head>
<body>

<div class="menutelefona">
    <input type="checkbox" id="hmt" class="hidden-menu-ticker">
<label class="btn-menu" for="hmt">
    <span class="first"></span>
    <span class="second"></span>
    <span class="third"></span>
</label>
  <ul class="hidden-menu">
    <li><a class="dek" href="indexxx.php">Домой</a></li>  
    <li><a class="dek" href="..\zdor\pages\histor.html">История</a></li>
    <li><a class="dek" href="..\zdor\pages\katalog.html">Каталог</a></li>  
    <li><a class="dek" href="..\zdor\pages\kontakt.html">Контакты</a></li>  
    <li><a class="dek" href="..\zdor\pages\nas.html">О нас</a></li> 
    
  </ul>
</div>
<?php ($_SESSION);
session_destroy(); ?>

<header class="header">
<div class="otstup">
  <div class="logo-headar">
    <img href="#" src="logo.svg"   id="logo-headar" >
  </div>
  <div class="menu">
	   <a href="indexxx.php" class="underline-one">Домой</a>
  </div>
<div class="menu">
      <a href="..\zdor\pages\histor.html" class="underline-one">История</a>
  </div>
<div class="menu">
<p> <a href="register.php?logout='1'" class="underline-one" style="color: green;">register</a> </p>
</div>
<div class="menu">
<p> <a href="login.php?logout='1'" class="underline-one" style="color: green;">login</a> </p>
</div>
<div class="menu">
<p> <a href="login.php?logout='1'"  class="underline-one" style="color: red;">logout</a> </p>
</div>
<div class="menu">
<button id="get-cart" type="button" class="btn btn-primary" data-toggle="modal" data-target="#cart-modal">
                        Корзина <span class="badge badge-light mini-cart-qty"><?=$_SESSION['cart.qty'] ?? 0 ?></span>
                    </button>
</div>      

<div class="menu">


</div>

</div>

</header>
<br>
<br>
<br>
<div class="wrapper mt-5">
    <div class="container">
        <div class="row">

            <div class="product-cards mb-5">

                <?php if (!empty($products1)): ?>
                    <?php foreach ($products1 as $product): ?>
                        <div class="product-card">
                            <div class="offer">
                                <?php if ($product['hit']): ?>
                                    <div class="offer-hit">Hit</div>
                                <?php endif; ?>
                                <?php if ($product['sale']): ?>
                                    <div class="offer-sale">Sale</div>
                                <?php endif; ?>
                            </div>
                            <div class="card-thumb">
                                <a href="#"><img src="img/<?= $product['img'] ?>" alt="<?= $product['title'] ?>"></a>
                            </div>
                            <div class="card-caption">
                                <div class="card-title">
                                    <a href="#"><?= $product['title'] ?></a>
                                </div>
                                <div class="card-price text-center">
                                    <?php if ($product['old_price']): ?>
                                        <del><?= $product['old_price'] ?> р.</del>
                                    <?php endif; ?>
                                    <?= $product['price'] ?> р.
                                </div>
                                <a href="?cart=add&id=<?= $product['id'] ?>" class="btn btn-info btn-block add-to-cart" data-id="<?= $product['id'] ?>">
                                    <i class="fas fa-cart-arrow-down"></i> Купить
                                </a>
                                <div class="item-status"><i class="fas fa-check text-success"></i> В наличии</div>
                            </div>
                        </div><!-- /product-card -->
                    <?php endforeach; ?>
                <?php endif; ?>

            </div><!-- /product-cards -->
            <div class="modal fade cart-modal" id="cart-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Корзина</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
           <div class="modal-cart-contennt">

           </div>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Оформить заказ</button>
            </div>
        </div>
    </div>
</div>
</div><br><br><br><br>
<footer class="footer">
    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave4"></div>
    </div>
    <ul class="social-icon">
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-facebook"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-twitter"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-linkedin"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-instagram"></ion-icon>
        </a></li>
    </ul>
    <ul class="menu">
    <li class="menu__item"><a class="menu__link" href="#">Главная</a></li>
      <li class="menu__item"><a class="menu__link" href="#">О нас</a></li>
      <li class="menu__item"><a class="menu__link" href="#">История</a></li>
      <li class="menu__item"><a class="menu__link" href="#">Контакты</a></li>
      <li class="menu__item"><a class="menu__link" href="#">Наши мастера</a></li>

    </ul>
    <p>&copy;2023 Milana Shop | All Rights Reserved</p>
  </footer>



</main>
</body>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="..\js\main.js"></script> 
<script src="..\js\app.js"></script>